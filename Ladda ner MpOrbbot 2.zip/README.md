# Mp ORBbot

AI-driven crypto trading bot based on Opening Range Breakout strategy.