import os
print("Mp ORBbot is running!")
# Placeholder for actual bot code