# MpOrbbot

En AI-baserad ORB-tradingbot som använder Telegram för statusmeddelanden.